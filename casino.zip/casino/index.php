<?php
session_start();
include 'funciones.php';

// Verificar si el usuario ya ha iniciado sesión
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    header("Location: menu.php");
    exit();
}

if (isset($_POST["submit"])) {
    $nombre = $_POST["nombre"];
    $apellidos = $_POST["apellidos"];
    $nick = $_POST["nick"];
    $edad = $_POST["edad"];

    // Validar los datos ingresados
    if (!empty($nombre) && !empty($apellidos) && !empty($nick) && is_numeric($edad) && $edad >= 18) {
        $_SESSION["logged_in"] = true;
        $_SESSION["nombre"] = $nombre;
        $_SESSION["apellidos"] = $apellidos;
        $_SESSION["nick"] = $nick;
        $_SESSION["saldo"] = 50;
        $_SESSION["hora_entrada"] = date("Y-m-d H:i:s");

        header("Location: menu.php");
        exit();
    } else {
        $error = "Debes ingresar todos los datos correctamente. Asegúrate de tener al menos 18 años.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>GonchySINO - Inicio de sesión</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/jpg" href="GonchySINO.svg"/>

</head>
<body>
    <div class="container">
        <h1>Iniciar sesión</h1>
        <?php if (isset($error)) { ?>
            <p class="error"><?php echo $error; ?></p>
        <?php } ?>
        <form method="POST" action="">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" required><br>
            <label for="apellidos">Apellidos:</label>
            <input type="text" name="apellidos" required><br>
            <label for="nick">Nick:</label>
            <input type="text" name="nick" required><br>
            <label for="edad">Edad:</label>
            <input type="number" name="edad" min="18" required><br>
            <input type="submit" name="submit" value="Iniciar sesión">
        </form>
    </div>
</body>
</html>
