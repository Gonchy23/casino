<?php
session_start();
include 'funciones.php';


// Función para incrementar el número de veces jugado de un juego específico
function incrementarVecesJugado($juego) {
    // Implementa la lógica para incrementar el número de veces jugado de un juego específico
    // Puedes almacenar esta información en una base de datos, en un archivo, o utilizar otra forma de persistencia de datos
    // En este ejemplo, se almacena en una variable de sesión

    if (!isset($_SESSION['veces_jugadas'])) {
        $_SESSION['veces_jugadas'] = array();
    }

    if (!isset($_SESSION['veces_jugadas'][$juego])) {
        $_SESSION['veces_jugadas'][$juego] = 0;
    }

    $_SESSION['veces_jugadas'][$juego]++;
}

// Función para obtener la fecha y hora actual en formato 'Y-m-d H:i:s'
function obtenerFechaHoraActual() {
    return date('Y-m-d H:i:s');
}

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header("Location: index.php");
    exit();
}

// Obtener la información del jugador de las variables de sesión
$nombre = $_SESSION['nombre'];
$apellidos = $_SESSION['apellidos'];
$nick = $_SESSION['nick'];
$saldo = $_SESSION['saldo'];

// Verificar si se ha seleccionado un juego
if (isset($_POST['game'])) {
    $game = $_POST['game'];

    // Calcular el ratio de uso y mostrar el mensaje si es necesario
    $currentTime = time();
    $lastPlayTime = isset($_SESSION['last_play_time']) ? $_SESSION['last_play_time'] : 0;
    $playCount = isset($_SESSION['play_count']) ? $_SESSION['play_count'] : 0;

    if (($currentTime - $lastPlayTime) < 60 && $playCount >= 3) {
        echo '<script>alert("Recuerda que si no hay diversión no hay juego.");</script>';
    }

    $_SESSION['last_play_time'] = $currentTime;
    $_SESSION['play_count'] = $playCount + 1;

    if ($game === 'dados') {
        incrementarVecesJugado('dados');
        $_SESSION['fechas_jugadas']['dados'] = obtenerFechaHoraActual();
        header("Location: dados.php");
        exit();
    } elseif ($game === 'ruleta') {
        incrementarVecesJugado('ruleta');
        $_SESSION['fechas_jugadas']['ruleta'] = obtenerFechaHoraActual();
        header("Location: ruleta.php");
        exit();
    } elseif ($game === 'baccarat') {
        incrementarVecesJugado('baccarat');
        $_SESSION['fechas_jugadas']['baccarat'] = obtenerFechaHoraActual();
        header("Location: baccarat.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>GonchySINO - Menú</title>
    <link rel="icon" type="image/jpg" href="GonchySINO.svg"/>
    <style>
        header {
            text-align: center;
            color: red;
            padding: 20px;
            margin-bottom: 0px;
        }

        header h1 {
            margin: 0;
            font-size: 50px;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background-color: green;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }

        .container {
            text-align: center;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            max-width: 800px;
            display: flex;
            justify-content: space-between;
        }

        h1 {
            color: red;
            font-size: 30px;
            margin-bottom: 20px;
        }

        .games-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .game-box {
            width: 30%;
            border: 1px solid #ccc;
            padding: 20px;
        }

        form {
            margin-top: 20px;
        }

        form button {
            margin-top: 10px;
        }

        .aside {
            width: 25%;
            background-color: #f2f2f2;
            padding: 20px;
            margin-left: 20px;
        }

        .main {
            flex: 75%;
        }

        .dark-mode {
            background-color: #333;
            color: #fff;
        }

        .dark-mode .aside {
            background-color: #333333;
        }

        .dark-mode .aside h2 {
        color: #ffffff;
        }

        .dark-mode .main {
        color: black;
        }
    </style>
</head>
<body>
    <header>
        <h1>GonchySINO</h1>
    </header>
    <div class="container">
        <div class="main">
            <h1>Bienvenido(a) <?php echo $nombre; ?></h1>

            <!-- Botón para cambiar el modo -->
            <button onclick="changeMode()">Cambiar Modo</button>

            <div class="games-container">
                <div class="game-box">
                    <h2>Juego de Dados</h2>
                    <p>Reglas del juego de Dados:</p>
                    <p>El jugador hace una apuesta.</p>
                    <p>El casino lanza los dados.</p>
                    <p>Si los dados muestran un siete o un once, el jugador gana la apuesta y recibe 1:1 de lo apostado.</p>
                    <p>Si los dados muestran cualquier otro resultado, el jugador pierde la apuesta.</p>
                    <form method="POST" action="">
                        <input type="hidden" name="game" value="dados">
                        <input type="submit" name="submit" value="Jugar Dados">
                    </form>
                </div>

                <div class="game-box">
                    <h2>Juego de Ruleta</h2>
                    <p>Reglas del juego de Ruleta:</p>
                    <p>El jugador hace una apuesta en un número o color específico.</p>
                    <p>El crupier hace girar la ruleta.</p>
                    <p>Si la bola se detiene en el número o color elegido por el jugador, este gana la apuesta y recibe el pago correspondiente.</p>
                    <p>Si la bola se detiene en cualquier otro número o color, el jugador pierde la apuesta.</p>
                    <form method="POST" action="">
                        <input type="hidden" name="game" value="ruleta">
                        <input type="submit" name="submit" value="Jugar Ruleta">
                    </form>
                </div>

                <div class="game-box">
                    <h2>Juego de Baccarat</h2>
                    <p>Reglas del juego de Baccarat:</p>
                    <p>El jugador hace una apuesta en el jugador, la banca o un empate.</p>
                    <p>Se reparten dos cartas al jugador y a la banca.</p>
                    <p>El objetivo del juego es obtener una suma de cartas lo más cercana posible a 9.</p>
                    <p>El valor de las cartas es el siguiente: ases valen 1, cartas del 2 al 9 valen su valor nominal y las figuras y el 10 valen 0.</p>
                    <form method="POST" action="">
                        <input type="hidden" name="game" value="baccarat">
                        <input type="submit" name="submit" value="Jugar Baccarat">
                    </form>
                </div>
            </div>
            <form action="menu.php" method="post">
                <button type="submit" name="add_funds">Añadir Fondos</button>
                <label for="dni">DNI:</label>
                <input type="text" name="dni" id="dni" required>
            </form>
            <a href="logout.php">Cerrar sesión</a>
        </div>

        <aside class="aside">
            <h2>Información de uso del casino</h2>
            <p>Datos completos de identificación del jugador:</p>
            <ul>
                <li>Nombre: <?php echo $nombre; ?></li>
                <li>Apellidos: <?php echo $apellidos; ?></li>
                <li>Nick: <?php echo $nick; ?></li>
            </ul>
            <p>Hora de entrada al casino: <?php echo date('H:i:s'); ?></p>
            <p>Saldo inicial: <?php echo $saldo; ?></p>
            <p>Estadísticas de uso del casino:</p>
            <ul>
                <li>Número de veces que se ha jugado cada juego:</li>
                <ul>
                    <li>Juego de Dados: <?php echo isset($_SESSION['play_count']['dados']) ? $_SESSION['play_count']['dados'] : 0; ?></li>
                    <li>Juego de Ruleta: <?php echo isset($_SESSION['play_count']['ruleta']) ? $_SESSION['play_count']['ruleta'] : 0; ?></li>
                    <li>Juego de Baccarat: <?php echo isset($_SESSION['play_count']['baccarat']) ? $_SESSION['play_count']['baccarat'] : 0; ?></li>
                </ul>
                <li>Fecha y hora exacta en que se ha jugado cada vez a cada juego:</li>
                <ul>
                <?php
                    $jugadas = obtenerJugadas($nick);
                    if ($jugadas != null && (is_array($jugadas) || is_object($jugadas))) {
                        foreach ($jugadas as $jugada) {
                            echo '<li>' . $jugada['fecha'] . ' ' . $jugada['hora'] . ' - Juego: ' . $jugada['juego'] . '</li>';
                        }
                    } else {
                        // Manejar el caso cuando $jugadas es nulo
                        echo "No se encontraron jugadas.";
                    }
                ?>
                </ul>
            </ul>
        </aside>

    </div>
    
    <script>
    function changeMode() {
        var body = document.body;
        var isDarkMode = body.classList.contains("dark-mode");

        // Si el modo actual es oscuro, lo desactivamos y almacenamos el valor
        if (isDarkMode) {
            body.classList.remove("dark-mode");
            localStorage.setItem("darkMode", "false");
        } else { // Si el modo actual es claro, lo activamos y almacenamos el valor
            body.classList.add("dark-mode");
            localStorage.setItem("darkMode", "true");
        }
    }

   // Verificar si se almacenó el valor del modo oscuro y aplicarlo al cargar la página
    window.addEventListener("load", function() {
        var isDarkMode = localStorage.getItem("darkMode") === "true";
        var body = document.body;

        if (isDarkMode) {
            body.classList.add("dark-mode");
        } else {
            body.classList.remove("dark-mode");
        }
    });
</script>

</body>
</html>
