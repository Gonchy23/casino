<?php
session_start();

// Obtener la información del jugador de las variables de sesión
$nombre = $_SESSION['nombre'];
$apellidos = $_SESSION['apellidos'];
$nick = $_SESSION['nick'];
$saldo = $_SESSION['saldo'];

// Verificar si se ha enviado una apuesta
if (isset($_POST['apuesta'])) {
    $apuesta = $_POST['apuesta'];

    // Verificar si la apuesta es válida
    if ($apuesta <= $saldo && $apuesta > 0) {
        // Realizar la apuesta
        $dado1 = rand(1, 6);
        $dado2 = rand(1, 6);
        $sumaDados = $dado1 + $dado2;

        // Verificar el resultado de los dados
        if ($sumaDados === 7 || $sumaDados === 11) {
            // El jugador gana la apuesta (recibe 1:1)
            $mensaje = "¡Has ganado! Ganaste $" . $apuesta;
            $saldo += $apuesta;
        } else {
            // El jugador pierde la apuesta
            $mensaje = "¡Has perdido! Perdiste $" . $apuesta;
            $saldo -= $apuesta;
        }

        // Actualizar el saldo en la sesión
        $_SESSION['saldo'] = $saldo;
    } else {
        $mensaje = "La apuesta no es válida.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Juego de Dados</title>
    <link rel="icon" type="image/jpg" href="GonchySINO.svg"/>

    <style>
        header{
            text-align: center;
            font-size: 30px;
        }
        body {
            background-color: green;
            color: white;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            max-width: 800px;
            margin: 20px auto;
        }

        .main {
            flex: 1;
            padding: 20px;
        }

        .aside {
            flex: 1;
            background-color: green;
            padding: 20px;
        }

        .dice {
            display: inline-block;
            width: 50px;
            height: 50px;
            background-color: white;
            border: 1px solid black;
            text-align: center;
            font-size: 24px;
            line-height: 50px;
            margin-right: 10px;
            color: red;
        }

        h1 {
            color: red;
        }
    </style>
</head>
<body>
    <header>
        <h1>GonchySINO</h1>
    </header>
    <div class="container">
        <div class="main">
            <h1>Juego de Dados</h1>
            <p>Bienvenido, <?php echo $nombre . " " . $apellidos; ?> (<?php echo $nick; ?>)</p>
            <p>Saldo actual: $<?php echo $saldo; ?></p>
            
            <?php if (isset($mensaje)): ?>
                <p><?php echo $mensaje; ?></p>
            <?php endif; ?>

            <form action="dados.php" method="post">
                <label for="apuesta">Haz tu apuesta:</label>
                <input type="number" name="apuesta" id="apuesta" min="1" max="<?php echo $saldo; ?>" required>
                <button type="submit">Lanzar Dados</button>
            </form>
            
            <h3>Dado 1: <span class="dice"><?php echo isset($dado1) ? $dado1 : '-'; ?></span></h3>
            <h3>Dado 2: <span class="dice"><?php echo isset($dado2) ? $dado2 : '-'; ?></span></h3>
            
            <form action="menu.php" method="post">
                <button type="submit">Volver al Menú Principal</button>
            </form>
        </div>
        
        <aside class="aside">
            <h2>Información de uso del casino</h2>
            <p>Datos completos de identificación del jugador:</p>
            <ul>
                <li>Nombre: <?php echo $nombre; ?></li>
                <li>Apellidos: <?php echo $apellidos; ?></li>
                <li>Nick: <?php echo $nick; ?></li>
            </ul>
            <p>Hora de entrada al casino: <?php echo date('H:i:s'); ?></p>
            <p>Saldo inicial: <?php echo $saldo; ?></p>
            <p>Estadísticas de uso del casino:</p>
            <ul>
                <li>Número de veces que se ha jugado cada juego:</li>
                <ul>
                    <li>Juego de Dados: <?php echo isset($numVecesDados) ? $numVecesDados : 0; ?></li>
                    <li>Juego de Ruleta: <?php echo isset($numVecesRuleta) ? $numVecesRuleta : 0; ?></li>
                    <li>Juego de Baccarat: <?php echo isset($numVecesBaccarat) ? $numVecesBaccarat : 0; ?></li>
                </ul>
                <li>Fecha y hora exacta en que se ha jugado cada vez:</li>
                <ul>
                    <?php if (isset($jugadas) && is_array($jugadas)) : ?>
                        <?php foreach ($jugadas as $jugada) : ?>
                            <li><?php echo $jugada['fecha']; ?> <?php echo $jugada['hora']; ?></li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li>No hay registros de jugadas.</li>
                    <?php endif; ?>
                </ul>
            </ul>
        </aside>
    </div>
</body>
</html>
