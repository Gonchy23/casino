<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pelicula = [
    'año' => $_POST['año'],
    'título' => $_POST['título'],
    'género' => $_POST['género'],
    'directores' => explode(',', $_POST['directores']),
  ];

  // Almacenamiento de datos de películas y directores en la sesión
  if (!isset($_SESSION['peliculas'])) {
    $_SESSION['peliculas'] = [];
  }
  $_SESSION['peliculas'][] = $pelicula;
}

// Búsqueda de películas por director
$peliculasDirector = [];
if (isset($_GET['director']) && isset($peliculas)) {
  $directorBusqueda = $_GET['director'];
  foreach ($peliculas as $pelicula) {
    if (in_array($directorBusqueda, $pelicula['directores'], true)) {
      $peliculasDirector[] = $pelicula;
    }
  }
}


?>

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <form action="" method="POST">
    <label for="año">Año:</label>
    <input type="text" name="año" required>

    <label for="título">Título:</label>
    <input type="text" name="título" required>

    <label for="género">Género:</label>
    <input type="text" name="género" required>

    <label for="directores">Directores:</label>
    <input type="text" name="directores" required>

    <button type="submit">Agregar</button>
  </form>

  <div id="resultados">
    <h2>Películas:</h2>
    <?php if (isset($_SESSION['peliculas'])) : ?>
      <ul>
        <?php foreach ($_SESSION['peliculas'] as $pelicula) : ?>
          <li>
            <strong>Año:</strong> <?php echo $pelicula['año']; ?> |
            <strong>Título:</strong> <?php echo $pelicula['título']; ?> |
            <strong>Género:</strong> <?php echo $pelicula['género']; ?> |
            <strong>Directores:</strong> <?php echo implode(', ', $pelicula['directores']); ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <?php if (count($peliculasDirector) > 0) : ?>
      <h2>Películas del director <?php echo $_GET['director']; ?>:</h2>
      <ul>
        <?php foreach ($peliculasDirector as $pelicula) : ?>
          <li>
            <strong>Año:</strong> <?php echo $pelicula['año']; ?> |
            <strong>Título:</strong> <?php echo $pelicula['título']; ?> |
            <strong>Género:</strong> <?php echo $pelicula['género']; ?> |
            <strong>Directores:</strong> <?php echo implode(', ', $pelicula['directores']); ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</body>
</html>
