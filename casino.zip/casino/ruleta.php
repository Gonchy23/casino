<?php
session_start();
include 'funciones.php';

// Verificar si el usuario no ha iniciado sesión
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header("Location: index.php");
    exit();
}

// Obtener la información del jugador de las variables de sesión
$nombre = $_SESSION['nombre'];
$apellidos = $_SESSION['apellidos'];
$nick = $_SESSION['nick'];
$saldo = $_SESSION['saldo'];

// Verificar si se ha enviado una apuesta y un número
if (isset($_POST['apuesta']) && isset($_POST['numero'])) {
    $apuesta = $_POST['apuesta'];
    $numero = $_POST['numero'];

    // Verificar si la apuesta y el número son válidos
    if ($apuesta <= $saldo && $apuesta > 0 && $numero >= 0 && $numero <= 37) {
        // Realizar la apuesta
        $resultado = jugarRuleta($apuesta, $numero);

        // Restar la apuesta al saldo del jugador
        $saldo -= $apuesta;

        // Actualizar el saldo en la sesión
        $_SESSION['saldo'] = $saldo;

        // Mostrar el resultado al jugador
        if ($resultado > 0) {
            $mensaje = "¡Has ganado! Ganaste $" . $resultado;
        } else {
            $mensaje = "¡Has perdido! Perdiste $" . abs($resultado);
        }
    } else {
        $mensaje = "La apuesta o el número no son válidos.";
    }
}

// Verificar si se ha pulsado el botón de añadir fondos
if (isset($_POST['add_funds'])) {
    // Verificar si se ha proporcionado el DNI
    if (isset($_POST['dni']) && !empty($_POST['dni'])) {
        $dni = $_POST['dni'];
        
        // Verificar si el DNI es válido (8 números y una letra mayúscula)
        if (preg_match('/^[0-9]{8}[A-Z]$/', $dni)) {
            // Añadir 10€ extras al saldo actual
            $saldo += 10;
            
            // Actualizar el saldo en la sesión
            $_SESSION['saldo'] = $saldo;
            
            $mensaje_fondos = "Se han añadido 10€ extras a tu saldo.";
        } else {
            $mensaje_fondos = "El formato del DNI no es válido.";
        }
    } else {
        $mensaje_fondos = "Por favor, introduce tu DNI para añadir fondos.";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Juego de Ruleta</title>
    <link rel="icon" type="image/jpg" href="GonchySINO.svg"/>

    <style>
        header {
            text-align: center;
            font-size: 30px;
        }

        body {
            background-color: green;
            color: white;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            max-width: 800px;
            margin: 20px auto;
        }

        .main {
            flex: 1;
            padding: 20px;
        }

        .aside {
            flex: 1;
            background-color: green;
            padding: 20px;
        }

        .roulette {
            display: inline-block;
            width: 50px;
            height: 50px;
            background-color: white;
            border: 1px solid black;
            text-align: center;
            font-size: 24px;
            line-height: 50px;
            margin-right: 10px;
            color: red;
        }

        h1 {
            color: red;
        }
    </style>
</head>
<body>
    <header>
        <h1>GonchySINO</h1>
    </header>
    <div class="container">
        <div class="main">
            <h1>Juego de Ruleta</h1>
            <p>Bienvenido, <?php echo $nombre . " " . $apellidos; ?> (<?php echo $nick; ?>)</p>
            <p>Saldo actual: $<?php echo $saldo; ?></p>

            <?php if (isset($mensaje)): ?>
                <p><?php echo $mensaje; ?></p>
            <?php endif; ?>

            <form action="ruleta.php" method="post">
                <label for="apuesta">Haz tu apuesta:</label>
                <input type="number" name="apuesta" id="apuesta" min="1" max="<?php echo $saldo; ?>" required>
                <br>
                <label for="numero">Elige un número (0-36):</label>
                <input type="number" name="numero" id="numero" min="0" max="36" required>
                <button type="submit">Jugar</button>
            </form>

            <?php
                if(isset($_POST['apuesta']) && isset($_POST['numero'])) {
                    $apuesta = $_POST['apuesta'];
                    $numeroSeleccionado = $_POST['numero'];
                    $numeroRuleta = rand(0, 36);

                    if ($numeroSeleccionado == $numeroRuleta) {
                        $saldo += $apuesta;
                        $mensaje = "¡Felicidades! Has ganado.";
                    } else {
                        $saldo -= $apuesta;
                        $mensaje = "Lo siento, has perdido.";
                    }
                }
            ?>

            <h3>Ruleta: <span class="roulette"><?php echo isset($numeroRuleta) ? '<span class="roulette-number">' . $numeroRuleta . '</span>' : '-'; ?></span></h3>

            <form action="menu.php" method="post">
                <button type="submit">Volver al Menú Principal</button>
            </form>
        </div>

        <aside class="aside">
            <h2>Información de uso del casino</h2>
            <p>Datos completos de identificación del jugador:</p>
            <ul>
                <li>Nombre: <?php echo $nombre; ?></li>
                <li>Apellidos: <?php echo $apellidos; ?></li>
                <li>Nick: <?php echo $nick; ?></li>
            </ul>
            <p>Hora de entrada al casino: <?php echo date('H:i:s'); ?></p>
            <p>Saldo inicial: <?php echo $saldo; ?></p>
            <p>Estadísticas de uso del casino:</p>
            <ul>
                <li>Número de veces que se ha jugado cada juego:</li>
                <ul>
                    <li>Juego de Dados: <?php echo isset($numVecesDados) ? $numVecesDados : 0; ?></li>
                    <li>Juego de Ruleta: <?php echo isset($numVecesRuleta) ? $numVecesRuleta : 0; ?></li>
                    <li>Juego de Baccarat: <?php echo isset($numVecesBaccarat) ? $numVecesBaccarat : 0; ?></li>
                </ul>
                <li>Fecha y hora exacta en que se ha jugado cada vez:</li>
                <ul>
                    <?php if (isset($jugadas) && is_array($jugadas)) : ?>
                        <?php foreach ($jugadas as $jugada) : ?>
                            <li><?php echo $jugada['fecha']; ?> <?php echo $jugada['hora']; ?></li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li>No hay registros de jugadas.</li>
                    <?php endif; ?>
                </ul>
            </ul>
        </aside>
    </div>
</body>
</html>


